PRAGMA foreign_keys = ON;
drop trigger if exists CharacterNameCheck;
drop view if exists PossibleCharacterName;
drop view if exists EpisodeWithSeriesId;
