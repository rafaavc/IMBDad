drop trigger if exists NomineesAwardUpdate;
drop trigger if exists NomineesAwardInsert;